// $(document).ready(function () {
//     console.log("lol" + document.getElementById('dodo').value);
//     $("#code").click(function () {
//         // var data = JSON.parse($("#data").val())
//         console.log($("#data").val());
//     });
// });